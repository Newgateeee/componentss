import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EncabezadohorientacionComponent } from './encabezadohorientacion.component';

describe('EncabezadohorientacionComponent', () => {
  let component: EncabezadohorientacionComponent;
  let fixture: ComponentFixture<EncabezadohorientacionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EncabezadohorientacionComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EncabezadohorientacionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
