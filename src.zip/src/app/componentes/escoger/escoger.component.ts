import {Component} from '@angular/core';
import {MatSelectModule} from '@angular/material/select';
import {MatFormFieldModule} from '@angular/material/form-field';
interface Food {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-escoger',
  standalone: true,
  imports: [MatFormFieldModule, MatSelectModule],

  templateUrl: './escoger.component.html',
  styleUrl: './escoger.component.css'
})
export class EscogerComponent {

    selected = 'option2';
}