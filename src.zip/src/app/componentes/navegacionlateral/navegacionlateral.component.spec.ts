import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NavegacionlateralComponent } from './navegacionlateral.component';

describe('NavegacionlateralComponent', () => {
  let component: NavegacionlateralComponent;
  let fixture: ComponentFixture<NavegacionlateralComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NavegacionlateralComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(NavegacionlateralComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
