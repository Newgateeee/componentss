import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BarraprogresoComponent } from './barraprogreso.component';

describe('BarraprogresoComponent', () => {
  let component: BarraprogresoComponent;
  let fixture: ComponentFixture<BarraprogresoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BarraprogresoComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BarraprogresoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
