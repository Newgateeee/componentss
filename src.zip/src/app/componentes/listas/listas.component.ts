import {Component} from '@angular/core';
import {MatListModule} from '@angular/material/list';
@Component({
  selector: 'app-listas',
  standalone: true,
  imports: [MatListModule],
  templateUrl: './listas.component.html',
  styleUrl: './listas.component.css'
})
export class ListasComponent {

}
