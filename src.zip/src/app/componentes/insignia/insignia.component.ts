import {Component} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import {MatBadgeModule} from '@angular/material/badge';

@Component({
  selector: 'app-insignia',
  standalone: true,
  imports: [MatBadgeModule, MatButtonModule, MatIconModule],
  templateUrl: './insignia.component.html',
  styleUrl: './insignia.component.css'
})
export class InsigniaComponent {
    hidden = false;
  
    toggleBadgeVisibility() {
      this.hidden = !this.hidden;
    }
  }
