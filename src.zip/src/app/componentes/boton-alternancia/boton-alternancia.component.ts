import {Component} from '@angular/core';
import {MatButtonToggleModule} from '@angular/material/button-toggle';

@Component({
  selector: 'app-boton-alternancia',
  standalone: true,
  imports: [MatButtonToggleModule],
  templateUrl: './boton-alternancia.component.html',
  styleUrl: './boton-alternancia.component.css'
})
export class BotonAlternanciaComponent {

}
