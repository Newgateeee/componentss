import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BotonAlternanciaComponent } from './boton-alternancia.component';

describe('BotonAlternanciaComponent', () => {
  let component: BotonAlternanciaComponent;
  let fixture: ComponentFixture<BotonAlternanciaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BotonAlternanciaComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BotonAlternanciaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
