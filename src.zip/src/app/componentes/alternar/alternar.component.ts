import {Component} from '@angular/core';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';

@Component({
  selector: 'app-alternar',
  standalone: true,
  imports:  [MatSlideToggleModule],
  templateUrl: './alternar.component.html',
  styleUrl: './alternar.component.css'
})
export class AlternarComponent {

}
