import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AlternarComponent } from './alternar.component';

describe('AlternarComponent', () => {
  let component: AlternarComponent;
  let fixture: ComponentFixture<AlternarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AlternarComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AlternarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
