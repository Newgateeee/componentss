import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CampoformComponent } from './campoform.component';

describe('CampoformComponent', () => {
  let component: CampoformComponent;
  let fixture: ComponentFixture<CampoformComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CampoformComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CampoformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
