// import {Component} from '@angular/core';
// import {
//   MatBottomSheet,
//   MatBottomSheetModule,
//   MatBottomSheetRef,
// } from '@angular/material/bottom-sheet';
// import {MatListModule} from '@angular/material/list';
// import {MatButtonModule} from '@angular/material/button';

// @Component({
//   selector: 'app-hoja-bandera',
//   standalone: true,
//   imports: [MatButtonModule, MatBottomSheetModule],
//   templateUrl: './hoja-bandera.component.html',
//   styleUrl: './hoja-bandera.component.css'
// })
// export class HojaBanderaComponent {

//   constructor(private _bottomSheet: MatBottomSheet) {}

//   openBottomSheet(): void {
//     this._bottomSheet.open(BottomSheetOverviewExampleSheet);
//   }
// }
// @Component({
//   selector: 'app-hoja-bandera',
//   standalone: true,
//   imports: [MatListModule],
//   templateUrl: './hoja-bandera.component.html',
//   styleUrl: './hoja-bandera.component.css'
// })
// export class BottomSheetOverviewExampleSheet {
//   constructor(private _bottomSheetRef: MatBottomSheetRef<BottomSheetOverviewExampleSheet>) {}

//   openLink(event: MouseEvent): void {
//     this._bottomSheetRef.dismiss();
//     event.preventDefault();
//   }
// }
