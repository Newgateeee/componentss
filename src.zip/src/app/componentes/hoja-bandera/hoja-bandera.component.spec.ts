import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HojaBanderaComponent } from './hoja-bandera.component';

describe('HojaBanderaComponent', () => {
  let component: HojaBanderaComponent;
  let fixture: ComponentFixture<HojaBanderaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HojaBanderaComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(HojaBanderaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
