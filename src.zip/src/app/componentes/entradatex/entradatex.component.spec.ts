import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntradatexComponent } from './entradatex.component';

describe('EntradatexComponent', () => {
  let component: EntradatexComponent;
  let fixture: ComponentFixture<EntradatexComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EntradatexComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EntradatexComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
