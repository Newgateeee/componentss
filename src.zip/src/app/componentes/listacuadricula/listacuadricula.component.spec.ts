import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListacuadriculaComponent } from './listacuadricula.component';

describe('ListacuadriculaComponent', () => {
  let component: ListacuadriculaComponent;
  let fixture: ComponentFixture<ListacuadriculaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ListacuadriculaComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ListacuadriculaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
