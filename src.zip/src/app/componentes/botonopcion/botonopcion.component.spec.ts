import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BotonopcionComponent } from './botonopcion.component';

describe('BotonopcionComponent', () => {
  let component: BotonopcionComponent;
  let fixture: ComponentFixture<BotonopcionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BotonopcionComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BotonopcionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
