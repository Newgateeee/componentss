import {Component} from '@angular/core';
import {MatRadioModule} from '@angular/material/radio';

@Component({
  selector: 'app-botonopcion',
  standalone: true,
  imports: [MatRadioModule],
  templateUrl: './botonopcion.component.html',
  styleUrl: './botonopcion.component.css'
})
export class BotonopcionComponent {

}
