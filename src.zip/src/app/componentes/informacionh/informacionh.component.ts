import {Component} from '@angular/core';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatButtonModule} from '@angular/material/button';

@Component({
  selector: 'app-informacionh',
  standalone: true,
  imports: [MatButtonModule, MatTooltipModule],
  templateUrl: './informacionh.component.html',
  styleUrl: './informacionh.component.css'
})
export class InformacionhComponent {

}
