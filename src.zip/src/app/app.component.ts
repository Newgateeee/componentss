import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AutocompletadoComponent } from "./componentes/autocompletado/autocompletado.component";
import { InsigniaComponent } from './componentes/insignia/insignia.component';
import { BotonComponent } from './componentes/boton/boton.component';
import { BotonAlternanciaComponent } from './componentes/boton-alternancia/boton-alternancia.component';
import { TarjetaComponent } from './componentes/tarjeta/tarjeta.component';
import { CasillaComponent } from './componentes/casilla/casilla.component';
import { ChipsComponent } from "./componentes/chips/chips.component";
import { FechasComponent } from "./componentes/fechas/fechas.component";
import { DivisorComponent } from "./componentes/divisor/divisor.component";
import { PanelComponent } from "./componentes/panel/panel.component";
import { CampoformComponent } from "./componentes/campoform/campoform.component";
import { ListacuadriculaComponent } from "./componentes/listacuadricula/listacuadricula.component";
import { IconosComponent } from "./componentes/iconos/iconos.component";
import { EntradatexComponent } from "./componentes/entradatex/entradatex.component";
import { ListasComponent } from "./componentes/listas/listas.component";
import { MenuComponent } from "./componentes/menu/menu.component";
import { PaginadorComponent } from "./componentes/paginador/paginador.component";
import { BarraprogresoComponent } from "./componentes/barraprogreso/barraprogreso.component";
import { BotonopcionComponent } from "./componentes/botonopcion/botonopcion.component";
import { EscogerComponent } from "./componentes/escoger/escoger.component";
import { NavegacionlateralComponent } from "./componentes/navegacionlateral/navegacionlateral.component";
import { SliderComponent } from "./componentes/slider/slider.component";
import { SnackbarComponent } from "./componentes/snackbar/snackbar.component";
import { PasosComponent } from "./componentes/pasos/pasos.component";
import { MesaComponent } from "./componentes/mesa/mesa.component";
import { HerramientasComponent } from "./componentes/herramientas/herramientas.component";
import { InformacionhComponent } from './componentes/informacionh/informacionh.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,
    AutocompletadoComponent,
    InsigniaComponent,
    BotonComponent,
    BotonAlternanciaComponent,
    TarjetaComponent,
    CasillaComponent,
    ChipsComponent,
    FechasComponent,
    DivisorComponent,
    PanelComponent,
    CampoformComponent,
    ListacuadriculaComponent,
    IconosComponent,
    EntradatexComponent,
    ListasComponent,
    MenuComponent,
    PaginadorComponent,
    BarraprogresoComponent,
    BotonopcionComponent,
    EscogerComponent,
    NavegacionlateralComponent,
    SliderComponent,
    SnackbarComponent,
    PasosComponent,
    MesaComponent,
    HerramientasComponent, 
    InformacionhComponent,
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'UnidadDos';
}
